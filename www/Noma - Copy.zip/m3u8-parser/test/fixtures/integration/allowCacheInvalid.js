module.exports = {
  allowCache: true,
  mediaSequence: 0,
  dateRanges: [],
  playlistType: 'VOD',
  segments: [
    {
      byterange: {
        length: 522828,
        offset: 0
      },
      duration: 10,
      timeline: 0,
      uri: 'hls_450k_video.ts'
    }
  ],
  targetDuration: 10,
  endList: true,
  discontinuitySequence: 0,
  discontinuityStarts: [],
  version: 4
};
