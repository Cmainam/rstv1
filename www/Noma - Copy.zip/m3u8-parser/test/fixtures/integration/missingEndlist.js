module.exports = {
  allowCache: true,
  dateRanges: [],
  mediaSequence: 0,
  segments: [
    {
      duration: 10,
      timeline: 0,
      uri: '00001.ts'
    },
    {
      duration: 10,
      timeline: 0,
      uri: '00002.ts'
    }
  ],
  targetDuration: 10,
  discontinuitySequence: 0,
  discontinuityStarts: []
};
