module.exports = {
  allowCache: true,
  dateRanges: [],
  discontinuityStarts: [],
  segments: []
};
