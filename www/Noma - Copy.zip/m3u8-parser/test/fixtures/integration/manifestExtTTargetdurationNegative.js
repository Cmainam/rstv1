module.exports = {
  allowCache: true,
  dateRanges: [],
  mediaSequence: 0,
  segments: [
    {
      duration: 10,
      timeline: 0,
      uri: '/test/ts-files/zencoder/gogo/00001.ts'
    }
  ],
  endList: true,
  discontinuitySequence: 0,
  discontinuityStarts: []
};
